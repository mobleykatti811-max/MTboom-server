import { apiClient } from './logic/apiClient.js';

// ===================================
// 🛑 临时测试区 (测试完可删除)
// ===================================
console.log('🚀 前端启动，准备连接香港服务器...');

async function testConnection() {
    try {
        // 1. 模拟登录一个“富二代”用户
        const myOpenId = "rich_kid_unsw_001";
        console.log('正在登录...');
        const loginRes = await apiClient.login(myOpenId, "淄博首富", "");
        console.log('✅ 登录成功! 用户ID:', loginRes.user.id);
        console.log('🚗 已拥有的豪车:', loginRes.unlocked_products);

        // 2. 模拟如果没车，就买一辆
        if (!loginRes.unlocked_products.includes('maserati_unlock')) {
            console.log('💳 没车？刷卡买一辆！(Mock支付)');
            await apiClient.createOrder(myOpenId, 'maserati_unlock', 99.9);
            console.log('🎉 支付成功！请刷新页面查看新车。');
        } else {
            console.log('👑 尊贵的玛莎拉弟弟车主，请直接入座。');
        }

    } catch (err) {
        console.error('💥 连接炸了:', err);
    }
}

// 执行测试
testConnection();
// ===================================