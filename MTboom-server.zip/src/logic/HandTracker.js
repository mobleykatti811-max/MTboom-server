import { FilesetResolver, HandLandmarker } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0';

/**
 * HandTracker - 交互核心类 (Sensor)
 * 职责：
 * 1. 启动摄像头并运行 MediaPipe AI 模型。
 * 2. 将原始坐标转换为业务指标 (Openness, Speed)。
 * 3. 过滤抖动，输出平滑的手势数据。
 */
export class HandTracker {
    constructor() {
        this.landmarker = null;
        this.video = null;
        this.lastVideoTime = -1;
        this.results = undefined;
        
        // --- 状态存储 ---
        this.gestureData = {
            x: 0.5,           // 屏幕位置 X (0~1)
            y: 0.5,           // 屏幕位置 Y (0~1)
            speed: 0,         // 挥手速度
            isOpen: false,    // 是否张开手掌 (触发爆灯)
            isFist: false,    // 是否握拳 (触发蓄力)
            openness: 0       // 开合度数值 (0.0 ~ 1.0)
        };

        // --- 内部计算变量 ---
        this.lastPos = { x: 0.5, y: 0.5, time: 0 };
    }

    /**
     * 初始化 AI 引擎与摄像头
     */
    async init() {
        // 1. 加载 MediaPipe 模型 (使用 CDN 避免本地大文件)
        const vision = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );

        // 2. 配置模型参数 (性能优先)
        this.landmarker = await HandLandmarker.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
                delegate: "GPU" // 尝试使用 GPU 加速
            },
            runningMode: "VIDEO",
            numHands: 1, // 只追踪一只手，减少计算量
            minHandDetectionConfidence: 0.5,
            minHandPresenceConfidence: 0.5,
            minTrackingConfidence: 0.5
        });

        // 3. 启动摄像头
        await this._setupCamera();
        
        console.log("🖐️ HandTracker: AI 视觉引擎已就绪");
    }

    /**
     * 每一帧检测 (被 main.js 循环调用)
     * 返回当前最新的手势状态
     */
    detect() {
        if (!this.landmarker || !this.video) return this.gestureData;

        // 只有当视频帧更新时才检测
        if (this.video.currentTime !== this.lastVideoTime) {
            this.lastVideoTime = this.video.currentTime;
            this.results = this.landmarker.detectForVideo(this.video, performance.now());
        }

        // 如果检测到了手
        if (this.results && this.results.landmarks.length > 0) {
            const landmarks = this.results.landmarks[0]; // 获取第一只手
            this._processLandmarks(landmarks);
        } else {
            // 没检测到手，速度归零，保持最后位置或复位
            this.gestureData.speed = 0; 
            this.gestureData.isOpen = false;
        }

        return this.gestureData;
    }

    // ==========================================
    // 私有方法：业务逻辑计算 (Math Magic)
    // ==========================================

    _setupCamera() {
        return new Promise((resolve) => {
            const video = document.createElement("video");
            video.setAttribute("playsinline", "");
            video.style.display = "none"; // 隐藏原始视频元素，我们只在 3D 里看

            navigator.mediaDevices.getUserMedia({ 
                video: { 
                    facingMode: "user", // 前置摄像头
                    width: { ideal: 640 }, // 降低分辨率以提高帧率
                    height: { ideal: 480 } 
                } 
            }).then((stream) => {
                video.srcObject = stream;
                video.addEventListener("loadeddata", () => {
                    video.play();
                    this.video = video;
                    resolve();
                });
            });
        });
    }

    /**
     * 核心算法：将坐标点翻译成“业务意图”
     * 对应你 PRD 文档里的算法逻辑
     */
    _processLandmarks(landmarks) {
        // 1. 获取核心点
        const wrist = landmarks[0];       // 手腕
        const indexTip = landmarks[8];    // 食指尖
        const thumbTip = landmarks[4];    // 拇指尖
        const middleRoot = landmarks[9];  // 中指根部

        // 2. 计算位置 (X轴镜像，因为摄像头是反的)
        const currentX = 1.0 - wrist.x;
        const currentY = 1.0 - wrist.y; // Y轴反转，让 0 在底部方便 3D 映射 (可选，视需求而定)

        // 平滑插值 (Lerp): 减少手抖造成的画面晃动
        // 0.2 的系数意味着：每帧只移动差距的 20%，让动作看起来很"肉"很平滑
        this.gestureData.x += (currentX - this.gestureData.x) * 0.2;
        this.gestureData.y += (currentY - this.gestureData.y) * 0.2;

        // 3. 计算开合度 (Openness) - 依据 PRD 算法
        // 逻辑：(拇指尖到食指尖距离) / (手腕到中指根部距离作为基准)
        const handSize = this._dist(wrist, middleRoot); // 手掌参考大小
        const pinchDist = this._dist(thumbTip, indexTip); // 捏合距离
        
        let ratio = pinchDist / (handSize * 1.2); // 归一化
        ratio = Math.min(Math.max(ratio, 0), 1);  // 限制在 0~1

        this.gestureData.openness = ratio;
        
        // 阈值判定
        this.gestureData.isFist = ratio < 0.2; // 握拳
        this.gestureData.isOpen = ratio > 0.7; // 张开 (触发爆灯)

        // 4. 计算挥手速度 (Speed) - 依据 PRD 算法
        const now = performance.now();
        const dt = now - this.lastPos.time;
        if (dt > 50) { // 每 50ms 计算一次速度
            const dx = currentX - this.lastPos.x;
            const dy = currentY - this.lastPos.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            // 速度 = 距离 / 时间
            // 放大系数 2000 是为了让数值好看 (0~10 之间)
            this.gestureData.speed = (dist / dt) * 2000; 
            
            this.lastPos = { x: currentX, y: currentY, time: now };
        }
    }

    // 辅助函数：计算两点距离 (欧几里得距离)
    _dist(p1, p2) {
        return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
    }
}