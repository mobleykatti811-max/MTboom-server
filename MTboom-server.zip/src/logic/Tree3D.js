import * as THREE from 'three';

/**
 * Tree3D - 视觉核心类 (Actor)
 * 职责：
 * 1. 生成基于数学螺旋的粒子系统 (无需加载外部模型，秒开)。
 * 2. 运行“土豪金” Shader，实现呼吸、闪烁、律动效果。
 * 3. 响应音频 (Beat) 和手势交互。
 */
export class Tree3D {
    constructor(scene) {
        this.scene = scene;
        this.mesh = null;
        this.material = null;
        this.geometry = null;

        // --- 配置参数 (可调整这里改变树的形态) ---
        this.params = {
            height: 14,         // 树高
            radius: 6,          // 底部半径
            count: 3000,        // 粒子数量 (2500-4000 是千元机甜点区)
            color: '#FFD700',   // 纯正土豪金
        };

        // --- Shader 变量 (用于控制特效) ---
        this.uniforms = {
            uTime: { value: 0 },   // 时间驱动 (呼吸/闪烁)
            uBeat: { value: 0 },   // 音频驱动 (动次打次)
            uColor: { value: new THREE.Color(this.params.color) }
        };
    }

    /**
     * 初始化：创建几何体与材质，并添加到舞台
     */
    init() {
        // 1. 生成数学几何体
        this.geometry = this._generateSpiralGeometry();

        // 2. 创建流光 Shader 材质
        this.material = this._createGoldShader();

        // 3. 构建网格
        this.mesh = new THREE.Points(this.geometry, this.material);
        
        // 4. 摆放位置 (向下平移，让树底座在屏幕下方)
        this.mesh.position.y = -this.params.height / 2;
        
        this.scene.add(this.mesh);
    }

    /**
     * 每一帧更新 (被 SceneManager 调用)
     * @param {number} time - 系统运行时间
     * @param {number} beat - 音频律动值 (0.0 ~ 1.0)
     */
    update(time, beat = 0) {
        if (!this.mesh) return;

        // 1. 更新时间，驱动 Shader 里的闪烁动画
        this.uniforms.uTime.value = time;

        // 2. 平滑处理音频信号 (Lerp)，防止画面抽搐
        // 如果 beat 突然变大，通过插值让树"Q弹"地变大
        const currentBeat = this.uniforms.uBeat.value;
        this.uniforms.uBeat.value += (beat - currentBeat) * 0.15;

        // 3. 待机自转 (缓缓转动展示)
        this.mesh.rotation.y = time * 0.15;
    }

    /**
     * 交互接口 (被 HandTracker 调用)
     * @param {number} rotationSpeed - 额外的旋转速度
     * @param {number} scaleFactor - 额外的缩放倍数
     */
    setInteraction(rotationSpeed, scaleFactor = 1) {
        if (!this.mesh) return;
        
        // 叠加手势旋转
        this.mesh.rotation.y += rotationSpeed;

        // 叠加手势缩放 (限制范围，防止缩太小看不见)
        const targetScale = Math.max(0.5, Math.min(2.0, scaleFactor));
        
        // 这里也可以加一个 Lerp 让缩放更平滑，暂时直接赋值
        this.mesh.scale.setScalar(targetScale);
    }

    // ==========================================
    // 下面是私有方法 (数学与图形学魔法)
    // ==========================================

    /**
     * 生成费马螺旋 (Fermat's Spiral) 点阵
     * 这比随机生成更好看，粒子分布均匀且有有机感
     */
    _generateSpiralGeometry() {
        const geometry = new THREE.BufferGeometry();
        const positions = [];
        const randoms = []; // 用于让每个粒子的闪烁频率不同
        const sizes = [];   // 粒子大小差异

        for (let i = 0; i < this.params.count; i++) {
            // 归一化高度 (0:底部 -> 1:顶部)
            // Math.pow(..., 0.8) 让粒子稍微向下聚集，树看起来更稳
            const h = i / this.params.count; 
            const hBias = Math.pow(h, 0.85);

            // 黄金角度 (137.508度)，大自然的密码
            const angle = i * 2.39996; 

            // 半径随高度收缩 (圆锥体)
            const r = this.params.radius * (1 - hBias);

            // 极坐标 -> 笛卡尔坐标
            const x = Math.cos(angle) * r;
            const y = hBias * this.params.height;
            const z = Math.sin(angle) * r;

            positions.push(x, y, z);
            
            // 随机属性
            randoms.push(Math.random()); 
            sizes.push(Math.random() * 0.5 + 0.5); // 0.5~1.0 基础大小
        }

        geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geometry.setAttribute('aRandom', new THREE.Float32BufferAttribute(randoms, 1));
        geometry.setAttribute('aSize', new THREE.Float32BufferAttribute(sizes, 1));

        return geometry;
    }

    /**
     * 创建 ShaderMaterial (视觉核心)
     * 这里的代码运行在 GPU 上，决定了你的产品看起来值多少钱
     */
    _createGoldShader() {
        // --- 顶点着色器 (Vertex Shader) ---
        // 决定每个粒子在屏幕上的位置和大小
        const vertexShader = `
            attribute float aRandom;
            attribute float aSize;
            
            uniform float uTime;
            uniform float uBeat;
            
            varying float vAlpha; // 传递给片元着色器的透明度

            void main() {
                vec3 pos = position;

                // [特效1] 律动膨胀 (Turbo Mode 核心)
                // 当 uBeat 变大，粒子沿着水平方向炸开，模拟"音浪"
                // 底部(pos.y小)受影响大，顶部受影响小
                float expansion = uBeat * 2.5 * (1.0 - pos.y / 15.0);
                pos.x += normalize(pos.x) * expansion;
                pos.z += normalize(pos.z) * expansion;

                // [特效2] 呼吸浮动
                // 粒子上下轻微浮动，显得有生命力
                pos.y += sin(uTime * 1.5 + aRandom * 5.0) * 0.15;

                vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
                gl_Position = projectionMatrix * mvPosition;

                // [特效3] 动态大小
                // 1. 距离衰减: (1.0 / -mvPosition.z) 离镜头越近越大
                // 2. 律动增强: uBeat 越大，粒子越大，产生爆闪感
                gl_PointSize = (20.0 * aSize + uBeat * 15.0) * (1.0 / -mvPosition.z);

                // [特效4] 闪烁计算
                // 利用 sin 函数制造忽明忽暗
                vAlpha = 0.6 + 0.4 * sin(uTime * 3.0 + aRandom * 10.0);
            }
        `;

        // --- 片元着色器 (Fragment Shader) ---
        // 决定每个粒子的颜色
        const fragmentShader = `
            uniform vec3 uColor;
            varying float vAlpha;

            void main() {
                // 1. 裁剪成圆形 (默认是方块)
                vec2 uv = gl_PointCoord - vec2(0.5);
                float r = length(uv);
                if (r > 0.5) discard;

                // 2. 径向渐变 (中心亮，边缘暗)
                // 这种光晕感是"像金子"的关键
                float glow = 1.0 - (r * 2.0);
                glow = pow(glow, 2.0); // 锐化光圈

                // 3. 合成颜色
                gl_FragColor = vec4(uColor, glow * vAlpha);
            }
        `;

        return new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms: this.uniforms,
            transparent: true,
            depthWrite: false,             // 关闭深度写入，让粒子可以前后叠加
            blending: THREE.AdditiveBlending // 核心：加法混合！粒子重叠处会变白亮
        });
    }
}