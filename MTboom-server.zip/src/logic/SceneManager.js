import * as THREE from 'three';
import { Tree3D } from './Tree3D.js';

// --- 引入后期处理模块 (让画面看起来"贵"的关键) ---
// 注意：这些路径依赖于 three 的 npm 包结构
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

/**
 * SceneManager - 舞台总管 (Stage)
 * 职责：
 * 1. 搭建 Three.js 环境 (相机、灯光、渲染器)。
 * 2. 集成 Post-Processing (辉光特效)，实现"土豪金"质感。
 * 3. 作为中转站，将 HandTracker 的数据传给 Tree3D。
 */
export class SceneManager {
    constructor(canvas) {
        this.canvas = canvas;
        this.width = window.innerWidth;
        this.height = window.innerHeight;

        // 核心组件
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.composer = null; // 后期特效合成器
        
        // 演员
        this.tree = null;

        // 状态
        this.clock = new THREE.Clock();
        this.isLowEndDevice = false; // 可扩展：低端机自动关闭特效
    }

    init() {
        this._setupScene();
        this._setupCamera();
        this._setupRenderer();
        this._setupPostProcessing(); // 开启滤镜
        this._addObjects();
        this._setupLights(); // 虽然粒子自发光，但加点灯光方便以后放玛莎拉蒂
        this._handleResize();
        
        console.log("🎬 SceneManager: 舞台搭建完毕");
    }

    /**
     * 渲染循环 (每一帧调用)
     * @param {object} gestureData - 从 HandTracker 传来的手势数据
     * @param {number} beatValue - 从 AudioManager 传来的音频律动值 (0~1)
     */
    render(gestureData, beatValue = 0) {
        const time = this.clock.getElapsedTime();

        // 1. 更新演员状态
        if (this.tree) {
            // 基础更新 (时间 + 音乐)
            this.tree.update(time, beatValue);

            // 交互更新 (手势)
            if (gestureData) {
                // 将手势速度映射为旋转速度 (挥手越快转越快)
                const rotateSpeed = gestureData.speed * 0.002;
                
                // 将手掌开合度映射为树的大小 (张手变大)
                // 基础大小 1.0 + 手势增量
                const scaleFactor = 1.0 + gestureData.openness * 0.8;

                this.tree.setInteraction(rotateSpeed, scaleFactor);
            }
        }

        // 2. 渲染画面
        // 如果开启了特效，必须用 composer.render()，而不是 renderer.render()
        if (this.composer) {
            this.composer.render();
        } else {
            this.renderer.render(this.scene, this.camera);
        }
    }

    // ==========================================
    // 私有方法：搭建舞台的苦力活
    // ==========================================

    _setupScene() {
        this.scene = new THREE.Scene();
        // 背景色设为深黑色，为了凸显金色的光
        this.scene.background = new THREE.Color(0x050505); 
        // 也可以加上雾效，增加深邃感
        this.scene.fog = new THREE.FogExp2(0x050505, 0.02);
    }

    _setupCamera() {
        this.camera = new THREE.PerspectiveCamera(60, this.width / this.height, 0.1, 1000);
        this.camera.position.set(0, 0, 20); // 相机后拉，确保能看到完整的树
        this.camera.lookAt(0, 0, 0);
    }

    _setupRenderer() {
        this.renderer = new THREE.WebGLRenderer({
            canvas: this.canvas,
            antialias: false, // 开启后处理时通常关闭原生抗锯齿以提升性能
            powerPreference: "high-performance"
        });
        this.renderer.setSize(this.width, this.height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // 限制像素比，防止高分屏卡顿
    }

    /**
     * 核心特效：UnrealBloomPass (虚幻引擎辉光)
     * 这里的参数决定了"土豪感"的浓度
     */
    _setupPostProcessing() {
        // 1. 创建合成器
        this.composer = new EffectComposer(this.renderer);
        
        // 2. 添加基础渲染通道 (先把场景画出来)
        const renderPass = new RenderPass(this.scene, this.camera);
        this.composer.addPass(renderPass);

        // 3. 添加辉光通道 (让亮的地方泛光)
        // 参数: resolution, strength, radius, threshold
        // Strength = 1.5 (强度): 越高越亮，太高会瞎眼
        // Radius = 0.4 (半径): 光晕扩散范围
        // Threshold = 0 (阈值): 亮度超过多少开始发光 (0代表所有东西都发光)
        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(this.width, this.height),
            1.5, 0.4, 0
        );
        this.composer.addPass(bloomPass);
    }

    _addObjects() {
        // 实例化 Tree3D 并加入场景
        this.tree = new Tree3D(this.scene);
        this.tree.init();
    }

    _setupLights() {
        // 环境光 (打底)
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);

        // 平行光 (模拟太阳，制造立体感)
        const dirLight = new THREE.DirectionalLight(0xffd700, 1.5);
        dirLight.position.set(5, 10, 7);
        this.scene.add(dirLight);
    }

    _handleResize() {
        window.addEventListener('resize', () => {
            this.width = window.innerWidth;
            this.height = window.innerHeight;

            this.camera.aspect = this.width / this.height;
            this.camera.updateProjectionMatrix();

            this.renderer.setSize(this.width, this.height);
            this.composer.setSize(this.width, this.height);
        });
    }
}